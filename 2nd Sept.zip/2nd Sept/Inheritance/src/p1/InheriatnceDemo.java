package p1;

class Employee extends Object
{
	int id;
	String name;
	double sal;
	
	public Employee() {
		System.out.println("Employee Default constructor called");
		this.id = 100;
		this.name = "Not Given";
		this.sal = 111;
	}
	public Employee(int id, String name, double sal) {
		System.out.println("Employee para constructor called");
		this.id = id;
		this.name = name;
		this.sal = sal;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	void display()
	{
		System.out.println("Id is :"+id);
		System.out.println("Name is:"+ name);
		System.out.println("Salary is:"+sal);
	}
	
}//emp ends here

class Salesmanager extends Employee
{
	double incentive;
	int target;
	
	public Salesmanager() {
		super();//parameter initialisation list
		this.incentive=99;
		this.target=80;
		System.out.println("SM Default constructor called");
	}
	public Salesmanager(int id, String name, double sal,double in,int t)
	{
		super(id, name, sal);//parameter initialisation list
		this.incentive=in;
		this.target=t;
		System.out.println("SM para constructor called");
	}
	public double getIncentive() {
		return incentive;
	}
	public void setIncentive(double incentive) {
		this.incentive = incentive;
	}
	public int getTarget() {
		return target;
	}
	public void setTarget(int target) {
		this.target = target;
	}
	
	void display()
	{
		super.display();
		System.out.println("Incentive is :"+this.incentive);
		System.out.println("Target is:"+this.target);
	}
}

public class InheriatnceDemo {

	
	public static void main(String[] args) {
		Salesmanager s2= new Salesmanager(102, "Rahul", 30000, 300, 30);
		
		System.out.println(s2.toString());
		
	}
	public static void main1(String[] args) {
		
		Salesmanager s1=new Salesmanager();//emp default & sm default
		s1.display();
		Salesmanager s2= new Salesmanager(102, "Rahul", 30000, 300, 30);
		//emp default & sm para
		s2.display();
	}

}
